# EyeBot Controller (Flutter / Dart)

Native port of controller.html. Same BLE protocol, same features: moods, 1-bit
drawing editor, photo import with dithering, quote cards, 10 picture slots,
GIF to animation, touch reactions, behaviour and eye-shape settings.

## Build
1. Install Flutter (https://docs.flutter.dev/get-started/install).
2. `flutter create --platforms=android,ios eyebot_controller`
3. Copy `lib/` and `pubspec.yaml` from this folder over the new project.
4. Add the permissions from `platform_snippets/` (Android manifest, iOS Info.plist).
5. `flutter pub get && flutter run` (plug in a real phone; BLE doesn't work in emulators).

Android needs minSdk 21+ (Flutter's default). The app asks for Bluetooth
permission the first time you tap Connect.
