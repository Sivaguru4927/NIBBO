import 'dart:async';
import 'dart:isolate';
import 'dart:math';
import 'dart:typed_data';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'ble.dart';
import 'imaging.dart';

void main() => runApp(const EyeBotApp());

const bg = Color(0xFF0B0F14), card = Color(0xFF141B24), dim = Color(0xFF8BA0B8);
const acc = Color(0xFF3DE0FF), line = Color(0xFF233042), okGreen = Color(0xFF5DFFB0);

const moods = ['normal', 'happy', 'surprised', 'sleepy', 'angry', 'sad', 'love', 'wink'];
final allModes = [...moods, ...List.generate(kSlots, (i) => 'img$i'), 'anim'];
String modeLabel(String m) => m.startsWith('img') ? 'picture ${m.substring(3)}' : m;

class EyeBotApp extends StatelessWidget {
  const EyeBotApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'EyeBot Controller',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: bg,
          colorScheme: const ColorScheme.dark(primary: acc, surface: card),
          useMaterial3: true,
        ),
        home: const ControllerPage(),
      );
}

class ControllerPage extends StatefulWidget {
  const ControllerPage({super.key});
  @override
  State<ControllerPage> createState() => _ControllerPageState();
}

class _ControllerPageState extends State<ControllerPage> {
  final ble = EyeBotBle();
  bool connected = false, statusOk = false;
  String status = 'Not connected';

  // editor
  Uint8List px = Uint8List(kW * kH);
  int rev = 0, brush = 2;
  bool pen = true, drawing = false, dither = true;
  int thr = 128;
  List<int>? last;
  Uint8List? srcGray;
  final undo = <Uint8List>[];
  final quoteCtl = TextEditingController();

  // slots
  int selSlot = 0;
  List<bool> filled = List.filled(kSlots, false);
  final thumbs = <int, Uint8List>{};
  double progress = 0;

  // settings
  String both = 'normal', top = 'normal', base = 'normal';
  int hold = 2000, bmin = 2000, bmax = 6000, sleepMin = 5, bright = 255;
  int ew = 28, eh = 30, er = 10, astart = 0, acount = 1, ams = 150;
  bool idle = true, invert = false;

  @override
  void dispose() {
    quoteCtl.dispose();
    ble.disconnect();
    super.dispose();
  }

  void _set(VoidCallback f) {
    if (mounted) setState(f);
  }

  void _status(String t, {bool ok = false}) => _set(() {
        status = t;
        statusOk = ok;
      });

  // ---------- connection ----------
  Future<void> _connect() async {
    _status('Searching…');
    try {
      ble.onDisconnected = () => _set(() {
            connected = false;
            status = 'Disconnected';
            statusOk = false;
          });
      final name = await ble.connect();
      await _readConfig();
      _set(() => connected = true);
      _status('Connected to $name', ok: true);
    } catch (e) {
      _status('$e');
    }
  }

  Future<void> _readConfig() async => _applyConfig(await ble.readConfig());

  void _applyConfig(Map<String, String> c) {
    int n(String? s, int d, int lo, int hi) => min(max(int.tryParse(s ?? '') ?? d, lo), hi);
    String mode(String? s, String d) => allModes.contains(s) ? s! : d;
    _set(() {
      both = mode(c['both'], both);
      top = mode(c['top'], top);
      base = mode(c['base'], base);
      hold = n(c['hold'], hold, 500, 8000);
      bright = n(c['bright'], bright, 0, 255);
      sleepMin = n(c['sleep'], sleepMin, 0, 60);
      final bl = (c['blink'] ?? '').split(',');
      if (bl.length == 2) {
        bmin = n(bl[0], bmin, 500, 10000);
        bmax = n(bl[1], bmax, 1000, 15000);
      }
      final ey = (c['eye'] ?? '').split(',');
      if (ey.length == 3) {
        ew = n(ey[0], ew, 14, 40);
        eh = n(ey[1], eh, 8, 44);
        er = n(ey[2], er, 0, 20);
      }
      idle = c['idle'] == '1';
      invert = c['invert'] == '1';
      final sl = c['slots'];
      if (sl != null) {
        filled = List.generate(kSlots, (k) => k < sl.length && sl[k] == '1');
        thumbs.removeWhere((k, _) => !filled[k]);
      }
      final an = (c['anim'] ?? '').split(',');
      if (an.length == 3) {
        astart = n(an[0], astart, 0, 9);
        acount = n(an[1], acount, 1, 10);
        ams = n(an[2], ams, 50, 1000);
      }
    });
  }

  // ---------- editor ----------
  void _snap() {
    undo.add(Uint8List.fromList(px));
    if (undo.length > 20) undo.removeAt(0);
  }

  void _setPx(Uint8List a) => _set(() {
        px = a;
        rev++;
      });

  List<int> _pos(Offset p, Size s) => [(p.dx / s.width * kW).floor(), (p.dy / s.height * kH).floor()];

  void _stamp(int x, int y) {
    final o = brush ~/ 2, v = pen ? 1 : 0;
    for (var dy = 0; dy < brush; dy++) {
      for (var dx = 0; dx < brush; dx++) {
        final X = x - o + dx, Y = y - o + dy;
        if (X >= 0 && X < kW && Y >= 0 && Y < kH) px[Y * kW + X] = v;
      }
    }
  }

  void _line(List<int> a, List<int> b) {
    var x0 = a[0], y0 = a[1];
    final x1 = b[0], y1 = b[1];
    final dx = (x1 - x0).abs(), dy = -(y1 - y0).abs();
    final sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
    var err = dx + dy;
    for (;;) {
      _stamp(x0, y0);
      if (x0 == x1 && y0 == y1) break;
      final e2 = 2 * err;
      if (e2 >= dy) {
        err += dy;
        x0 += sx;
      }
      if (e2 <= dx) {
        err += dx;
        y0 += sy;
      }
    }
  }

  Widget _editor() => Container(
        decoration: BoxDecoration(
            color: Colors.black, border: Border.all(color: line, width: 2), borderRadius: BorderRadius.circular(8)),
        child: LayoutBuilder(builder: (context, cons) {
          final size = Size(cons.maxWidth, cons.maxWidth / 2);
          return RawGestureDetector(
            // claim the touch so the page doesn't scroll while drawing
            gestures: {
              EagerGestureRecognizer: GestureRecognizerFactoryWithHandlers<EagerGestureRecognizer>(
                  () => EagerGestureRecognizer(), (_) {})
            },
            child: Listener(
              onPointerDown: (e) {
                _snap();
                drawing = true;
                last = _pos(e.localPosition, size);
                _stamp(last![0], last![1]);
                _setPx(px);
              },
              onPointerMove: (e) {
                if (!drawing) return;
                final p = _pos(e.localPosition, size);
                _line(last!, p);
                last = p;
                _setPx(px);
              },
              onPointerUp: (_) => drawing = false,
              onPointerCancel: (_) => drawing = false,
              child: SizedBox.fromSize(size: size, child: CustomPaint(painter: PixelPainter(px, rev))),
            ),
          );
        }),
      );

  void _applySource() {
    if (srcGray != null) _setPx(grayToPx(srcGray!, thr, dither));
  }

  Future<Uint8List?> _pickBytes() async {
    final f = await ImagePicker().pickImage(source: ImageSource.gallery);
    return f?.readAsBytes();
  }

  Future<void> _pickPhoto() async {
    try {
      final bytes = await _pickBytes();
      if (bytes == null) return;
      final d = await Isolate.run(() => decodeGrays(bytes, false));
      _snap();
      srcGray = d.grays.first;
      _applySource();
    } catch (_) {
      _status('Could not read that image');
    }
  }

  Future<void> _makeQuote() async {
    final t = quoteCtl.text.trim();
    if (t.isEmpty) return;
    FocusScope.of(context).unfocus();
    _snap();
    srcGray = null;
    _setPx(await quoteToPx(t));
  }

  // ---------- slots ----------
  Future<void> _sendDrawing() async {
    try {
      _status('Sending to slot $selSlot…');
      await ble.sendPicture(selSlot, px, onProgress: (f) => _set(() => progress = f));
      thumbs[selSlot] = Uint8List.fromList(px);
      _status('Saved to slot $selSlot on the keychain', ok: true);
      await Future.delayed(const Duration(milliseconds: 400));
      await _readConfig();
    } catch (e) {
      _status('Send failed: $e');
    }
    await Future.delayed(const Duration(milliseconds: 800));
    _set(() => progress = 0);
  }

  Future<void> _deleteSlot() async {
    await ble.send('del=$selSlot');
    thumbs.remove(selSlot);
    await Future.delayed(const Duration(milliseconds: 300));
    await _readConfig();
  }

  Future<void> _importGif() async {
    try {
      final bytes = await _pickBytes();
      if (bytes == null) return;
      _status('Reading GIF…');
      final d = await Isolate.run(() => decodeGrays(bytes, true));
      final start = selSlot, total = d.grays.length, count = min(kSlots - start, total);
      if (count < 1) {
        _status('Pick an earlier slot first');
        return;
      }
      final totalMs = d.durations.fold<int>(0, (a, b) => a + b);
      for (var i = 0; i < count; i++) {
        final a = grayToPx(d.grays[(i * total / count).floor()], thr, dither);
        _status('Sending frame ${i + 1} of $count…');
        await ble.sendPicture(start + i, a, onProgress: (p) => _set(() => progress = (i + p) / count));
        thumbs[start + i] = Uint8List.fromList(a);
        if (i == 0) _setPx(Uint8List.fromList(a));
      }
      final frameMs = min(max((totalMs / count).round(), 80), 1000);
      await ble.send('animcfg=$start,$count,$frameMs');
      await ble.send('mood=anim');
      _status('GIF saved to slots $start–${start + count - 1} as an animation', ok: true);
      await Future.delayed(const Duration(milliseconds: 400));
      await _readConfig();
    } catch (e) {
      _status('GIF import failed: $e');
    }
    await Future.delayed(const Duration(milliseconds: 800));
    _set(() => progress = 0);
  }

  Future<void> _playAnim() async {
    final c = min(acount, kSlots - astart);
    await ble.send('animcfg=$astart,$c,$ams');
    await ble.send('mood=anim');
  }

  // ---------- small UI helpers ----------
  Widget _card(String title, List<Widget> kids) => Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
            color: card, border: Border.all(color: line), borderRadius: BorderRadius.circular(14)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title.toUpperCase(),
              style: const TextStyle(color: dim, fontSize: 13, fontWeight: FontWeight.w600, letterSpacing: .8)),
          const SizedBox(height: 10),
          ...kids,
        ]),
      );

  Widget _btn(String label, VoidCallback onTap, {bool on = false}) => FilledButton(
        onPressed: onTap,
        style: FilledButton.styleFrom(
          backgroundColor: on ? acc : const Color(0xFF1C2735),
          foregroundColor: on ? const Color(0xFF04222A) : Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
        child: Text(label),
      );

  Widget _slider(String label, int v, int lo, int hi, int step, String Function(int) fmt,
      ValueChanged<int> onChanged, [VoidCallback? onEnd]) {
    return Row(children: [
      Expanded(flex: 4, child: Text(label)),
      Expanded(
        flex: 5,
        child: Slider(
          value: v.toDouble().clamp(lo.toDouble(), hi.toDouble()),
          min: lo.toDouble(),
          max: hi.toDouble(),
          divisions: (hi - lo) ~/ step,
          onChanged: (x) => onChanged(x.round()),
          onChangeEnd: onEnd == null ? null : (_) => onEnd(),
        ),
      ),
      SizedBox(width: 56, child: Text(fmt(v), textAlign: TextAlign.right, style: const TextStyle(color: acc))),
    ]);
  }

  Widget _switch(String label, bool v, ValueChanged<bool> onChanged) => Row(children: [
        Expanded(child: Text(label)),
        Switch(value: v, onChanged: onChanged),
      ]);

  Widget _modeDrop(String label, String v, ValueChanged<String> onChanged) => Row(children: [
        Expanded(child: Text(label)),
        DropdownButton<String>(
          value: v,
          items: allModes.map((m) => DropdownMenuItem(value: m, child: Text(modeLabel(m)))).toList(),
          onChanged: (x) => x == null ? null : onChanged(x),
        ),
      ]);

  String _sec(int v) => '${(v / 1000).toStringAsFixed(1)}s';
  String _num(int v) => '$v';

  // ---------- build ----------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: ListView(padding: const EdgeInsets.all(16), children: [
              const Text('EyeBot Controller', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              const Text('Connect to your keychain over Bluetooth, change its behaviour and give it your own pictures.',
                  style: TextStyle(color: dim, fontSize: 14)),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: _connect,
                style: FilledButton.styleFrom(
                    backgroundColor: acc,
                    foregroundColor: const Color(0xFF04222A),
                    padding: const EdgeInsets.all(14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                child: const Text('Connect to EyeBot', style: TextStyle(fontWeight: FontWeight.w700)),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Text(status,
                    textAlign: TextAlign.center, style: TextStyle(color: statusOk ? okGreen : dim, fontSize: 14)),
              ),
              IgnorePointer(
                ignoring: !connected,
                child: Opacity(opacity: connected ? 1 : .4, child: _panel()),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _panel() => Column(children: [
        _card('Play a mood now', [
          GridView.count(
            crossAxisCount: 4,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            childAspectRatio: 1.7,
            children: [
              for (final m in moods)
                FilledButton(
                  onPressed: () => ble.send('mood=$m'),
                  style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFF1C2735),
                      foregroundColor: Colors.white,
                      padding: EdgeInsets.zero,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                  child: FittedBox(child: Text(m)),
                ),
            ],
          ),
        ]),
        _card('Your pictures', [
          _editor(),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
            _btn('Pen', () => _set(() => pen = true), on: pen),
            _btn('Eraser', () => _set(() => pen = false), on: !pen),
            DropdownButton<int>(
              value: brush,
              items: [1, 2, 3, 5].map((s) => DropdownMenuItem(value: s, child: Text('$s px'))).toList(),
              onChanged: (v) => _set(() => brush = v ?? brush),
            ),
            _btn('Undo', () {
              if (undo.isNotEmpty) _setPx(undo.removeLast());
            }),
            _btn('Clear', () {
              _snap();
              srcGray = null;
              _setPx(Uint8List(kW * kH));
            }),
            _btn('Invert', () {
              _snap();
              _setPx(Uint8List.fromList(px.map((v) => v == 0 ? 1 : 0).toList()));
            }),
          ]),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            _btn('Photo from gallery', _pickPhoto),
            _btn('GIF → animation', _importGif),
          ]),
          _slider('Photo brightness cut-off', thr, 20, 235, 1, _num, (v) {
            thr = v;
            _applySource();
            _set(() {});
          }),
          _switch('Smooth shading (dither)', dither, (v) {
            dither = v;
            _applySource();
            _set(() {});
          }),
          TextField(
            controller: quoteCtl,
            minLines: 2,
            maxLines: 5,
            decoration: InputDecoration(
              hintText: 'Type a quote…  (new lines are kept)',
              filled: true,
              fillColor: const Color(0xFF1C2735),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 8),
          _btn('Make quote card', _makeQuote),
          const SizedBox(height: 14),
          const Text('SEND TO SLOT',
              style: TextStyle(color: dim, fontSize: 13, fontWeight: FontWeight.w600, letterSpacing: .8)),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 5,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            childAspectRatio: 2,
            children: [for (var i = 0; i < kSlots; i++) _slot(i)],
          ),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            _btn('Send drawing to slot $selSlot', _sendDrawing),
            _btn('Delete slot', _deleteSlot),
          ]),
          const SizedBox(height: 8),
          LinearProgressIndicator(value: progress, minHeight: 6, backgroundColor: const Color(0xFF1C2735)),
          const SizedBox(height: 8),
          const Text(
              'Tap a filled slot to show it on the keychain. To use a picture as the bot\'s face, set "Resting face" below to that picture.',
              style: TextStyle(color: dim, fontSize: 13)),
          const SizedBox(height: 14),
          const Text('ANIMATION FROM SLOTS',
              style: TextStyle(color: dim, fontSize: 13, fontWeight: FontWeight.w600, letterSpacing: .8)),
          _slider('First slot', astart, 0, 9, 1, _num, (v) => _set(() => astart = v)),
          _slider('Frames', acount, 1, 10, 1, _num, (v) => _set(() => acount = v)),
          _slider('Frame time', ams, 50, 1000, 10, (v) => '${v}ms', (v) => _set(() => ams = v)),
          _btn('Play animation', _playAnim),
        ]),
        _card('Touch reactions', [
          _modeDrop('Left + right together', both, (v) {
            _set(() => both = v);
            ble.send('both=$v');
          }),
          _modeDrop('Touch on top', top, (v) {
            _set(() => top = v);
            ble.send('top=$v');
          }),
          _modeDrop('Resting face', base, (v) {
            _set(() => base = v);
            ble.send('base=$v');
          }),
          _slider('Reaction time', hold, 500, 8000, 100, _sec, (v) => _set(() => hold = v), () => ble.send('hold=$hold')),
          _switch('Swap left / right look', invert, (v) {
            _set(() => invert = v);
            ble.send('invert=${v ? 1 : 0}');
          }),
          const Text('Hold the top pad for 1 second to wake the keychain from sleep.',
              style: TextStyle(color: dim, fontSize: 13)),
        ]),
        _card('Behaviour', [
          _slider('Blink at least every', bmin, 500, 10000, 100, _sec, (v) => _set(() => bmin = v),
              () => ble.send('blink=$bmin,$bmax')),
          _slider('Blink at most every', bmax, 1000, 15000, 100, _sec, (v) => _set(() => bmax = v),
              () => ble.send('blink=$bmin,$bmax')),
          _switch('Look around by itself', idle, (v) {
            _set(() => idle = v);
            ble.send('idle=${v ? 1 : 0}');
          }),
          _slider('Sleep after (0 = never)', sleepMin, 0, 60, 1, (v) => '${v}m', (v) => _set(() => sleepMin = v),
              () => ble.send('sleep=$sleepMin')),
          _slider('Screen brightness', bright, 0, 255, 5, _num, (v) => _set(() => bright = v),
              () => ble.send('bright=$bright')),
        ]),
        _card('Eye shape', [
          _slider('Width', ew, 14, 40, 1, _num, (v) => _set(() => ew = v), () => ble.send('eye=$ew,$eh,$er')),
          _slider('Height', eh, 8, 44, 1, _num, (v) => _set(() => eh = v), () => ble.send('eye=$ew,$eh,$er')),
          _slider('Roundness', er, 0, 20, 1, _num, (v) => _set(() => er = v), () => ble.send('eye=$ew,$eh,$er')),
        ]),
        SizedBox(
          width: double.infinity,
          child: _btn('Reset settings to defaults', () async {
            await ble.send('reset');
            await Future.delayed(const Duration(milliseconds: 600));
            await _readConfig();
          }),
        ),
        const SizedBox(height: 24),
      ]);

  Widget _slot(int i) {
    final sel = i == selSlot;
    return GestureDetector(
      onTap: () {
        _set(() => selSlot = i);
        if (filled[i]) ble.send('mood=img$i');
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: sel ? acc : (filled[i] ? const Color(0xFF2B4A5A) : line), width: 2),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: Stack(fit: StackFit.expand, children: [
            if (thumbs[i] != null) CustomPaint(painter: PixelPainter(thumbs[i]!)),
            Positioned(
                left: 4,
                top: 2,
                child: Text('$i', style: const TextStyle(fontSize: 12, shadows: [Shadow(blurRadius: 3)]))),
          ]),
        ),
      ),
    );
  }
}
