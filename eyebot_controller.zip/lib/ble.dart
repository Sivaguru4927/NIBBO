import 'dart:async';
import 'dart:convert';
import 'dart:io' show Platform;
import 'dart:math';
import 'dart:typed_data';

import 'package:flutter_blue_plus/flutter_blue_plus.dart';

import 'imaging.dart';

class EyeBotBle {
  static final _service = Guid('a7e10001-5b1d-4c6e-9f3a-2d8c0b6e7f10');
  static final _cmdId = Guid('a7e10002-5b1d-4c6e-9f3a-2d8c0b6e7f10');
  static final _cfgId = Guid('a7e10003-5b1d-4c6e-9f3a-2d8c0b6e7f10');
  static final _imgId = Guid('a7e10004-5b1d-4c6e-9f3a-2d8c0b6e7f10');

  BluetoothDevice? _device;
  BluetoothCharacteristic? _cmd, _cfg, _img;
  StreamSubscription<BluetoothConnectionState>? _stateSub;
  Future<void> _queue = Future.value();
  void Function()? onDisconnected;

  bool get connected => _cmd != null && _cfg != null && _img != null;

  /// One BLE operation at a time.
  Future<T> _enqueue<T>(Future<T> Function() fn) {
    final p = _queue.then((_) => fn());
    _queue = p.then((_) {}, onError: (_) {});
    return p;
  }

  void _clear() {
    _cmd = _cfg = _img = null;
  }

  /// Scans for a device named "EyeBot…", connects and returns its name.
  Future<String> connect() async {
    if (!await FlutterBluePlus.isSupported) {
      throw 'Bluetooth is not supported on this device.';
    }
    final adapter = await FlutterBluePlus.adapterState
        .where((s) => s != BluetoothAdapterState.unknown)
        .first
        .timeout(const Duration(seconds: 5), onTimeout: () => BluetoothAdapterState.unknown);
    if (adapter != BluetoothAdapterState.on) throw 'Please turn Bluetooth on.';

    final found = Completer<(BluetoothDevice, String)>();
    final sub = FlutterBluePlus.scanResults.listen((results) {
      for (final r in results) {
        final name =
            r.advertisementData.advName.isNotEmpty ? r.advertisementData.advName : r.device.platformName;
        if (name.startsWith('EyeBot') && !found.isCompleted) found.complete((r.device, name));
      }
    });
    late final BluetoothDevice device;
    late final String name;
    try {
      await FlutterBluePlus.startScan(timeout: const Duration(seconds: 12));
      (device, name) = await found.future.timeout(const Duration(seconds: 12));
    } on TimeoutException {
      throw 'No EyeBot found. Is it awake and nearby?';
    } finally {
      await FlutterBluePlus.stopScan();
      await sub.cancel();
    }

    await device.connect(timeout: const Duration(seconds: 15));
    // Image packets are 103 bytes, so ask for a bigger MTU (Android; iOS negotiates itself).
    if (Platform.isAndroid) {
      try {
        await device.requestMtu(247);
      } catch (_) {}
    }
    _device = device;
    _stateSub?.cancel();
    _stateSub = device.connectionState.listen((s) {
      if (s == BluetoothConnectionState.disconnected) {
        _clear();
        onDisconnected?.call();
      }
    });

    final services = await device.discoverServices();
    final svc = services.firstWhere((s) => s.uuid == _service,
        orElse: () => throw 'EyeBot service not found on this device.');
    BluetoothCharacteristic ch(Guid g) => svc.characteristics.firstWhere((c) => c.uuid == g);
    _cmd = ch(_cmdId);
    _cfg = ch(_cfgId);
    _img = ch(_imgId);
    return name;
  }

  Future<void> disconnect() async {
    await _stateSub?.cancel();
    await _device?.disconnect();
    _clear();
  }

  Future<void> send(String text) {
    if (_cmd == null) return Future.value();
    return _enqueue(() => _cmd!.write(utf8.encode(text)));
  }

  Future<void> sendPicture(int slot, Uint8List px, {void Function(double)? onProgress}) async {
    final bytes = packBits(px);
    for (var off = 0; off < bytes.length; off += kChunk) {
      final n = min(kChunk, bytes.length - off);
      final pkt = Uint8List(3 + n)
        ..[0] = slot
        ..[1] = off & 255
        ..[2] = off >> 8
        ..setRange(3, 3 + n, bytes, off);
      await _enqueue(() => _img!.write(pkt));
      onProgress?.call((off + n) / bytes.length);
    }
  }

  Future<Map<String, String>> readConfig() async {
    final raw = utf8.decode(await _enqueue(() => _cfg!.read()));
    final m = <String, String>{};
    for (final part in raw.split(';')) {
      final i = part.indexOf('=');
      if (i > 0) m[part.substring(0, i)] = part.substring(i + 1);
    }
    return m;
  }
}
