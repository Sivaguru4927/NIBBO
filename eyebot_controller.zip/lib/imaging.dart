import 'dart:math';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;

const int kW = 128, kH = 64, kSlots = 10, kChunk = 100;

/// Result of decoding a picture: one 128x64 grayscale buffer per frame.
class Decoded {
  final List<Uint8List> grays;
  final List<int> durations; // ms per frame
  Decoded(this.grays, this.durations);
}

/// Runs in a background isolate: decode, fit inside 128x64 (keeping
/// proportions, black padding) and convert to grayscale.
Decoded decodeGrays(Uint8List bytes, bool allFrames) {
  final decoded = img.decodeImage(bytes);
  if (decoded == null) throw const FormatException('Unsupported image');
  final frames = allFrames ? decoded.frames : [img.bakeOrientation(decoded)];
  final grays = <Uint8List>[];
  final durations = <int>[];
  for (final frame in frames) {
    var f = frame;
    if (f.hasPalette) f = f.convert(numChannels: 4);
    grays.add(_toGray(f));
    durations.add(frame.frameDuration > 0 ? frame.frameDuration : 100);
  }
  return Decoded(grays, durations);
}

Uint8List _toGray(img.Image src) {
  final k = min(kW / src.width, kH / src.height);
  final dw = max(1, (src.width * k).round()), dh = max(1, (src.height * k).round());
  final r = img.copyResize(src,
      width: dw, height: dh, interpolation: img.Interpolation.average);
  final out = Uint8List(kW * kH);
  final ox = (kW - dw) ~/ 2, oy = (kH - dh) ~/ 2;
  for (var y = 0; y < dh; y++) {
    for (var x = 0; x < dw; x++) {
      final p = r.getPixel(x, y);
      final a = p.aNormalized;
      final lum = (0.299 * p.rNormalized + 0.587 * p.gNormalized + 0.114 * p.bNormalized) * a;
      final X = x + ox, Y = y + oy;
      if (X >= 0 && X < kW && Y >= 0 && Y < kH) out[Y * kW + X] = (lum * 255).round().clamp(0, 255);
    }
  }
  return out;
}

/// Grayscale -> 1-bit (1 = lit pixel), optionally Floyd–Steinberg dithered.
Uint8List grayToPx(Uint8List gray, int thr, bool dither) {
  final out = Uint8List(kW * kH);
  if (dither) {
    final g = Float32List(kW * kH);
    for (var i = 0; i < g.length; i++) {
      g[i] = gray[i].toDouble();
    }
    for (var y = 0; y < kH; y++) {
      for (var x = 0; x < kW; x++) {
        final i = y * kW + x, old = g[i], nw = old < thr ? 0.0 : 255.0, err = old - nw;
        out[i] = nw > 0 ? 1 : 0;
        if (x + 1 < kW) g[i + 1] += err * 7 / 16;
        if (y + 1 < kH) {
          if (x > 0) g[i + kW - 1] += err * 3 / 16;
          g[i + kW] += err * 5 / 16;
          if (x + 1 < kW) g[i + kW + 1] += err * 1 / 16;
        }
      }
    }
  } else {
    for (var i = 0; i < out.length; i++) {
      out[i] = gray[i] >= thr ? 1 : 0;
    }
  }
  return out;
}

/// Renders centred, auto-sized, word-wrapped text into a 1-bit picture.
Future<Uint8List> quoteToPx(String text) async {
  late TextPainter tp;
  for (var size = 24; size >= 8; size--) {
    tp = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
            color: Colors.white,
            fontSize: size.toDouble(),
            fontWeight: FontWeight.w600,
            height: 1.15),
      ),
      textAlign: TextAlign.center,
      textDirection: TextDirection.ltr,
    )..layout(minWidth: kW - 8.0, maxWidth: kW - 8.0);
    if (tp.height <= kH - 4) break;
  }
  final rec = ui.PictureRecorder();
  final c = Canvas(rec, Rect.fromLTWH(0, 0, kW.toDouble(), kH.toDouble()));
  c.drawRect(Rect.fromLTWH(0, 0, kW.toDouble(), kH.toDouble()), Paint()..color = Colors.black);
  tp.paint(c, Offset(4, max(0.0, (kH - tp.height) / 2)));
  final image = await rec.endRecording().toImage(kW, kH);
  final data = (await image.toByteData(format: ui.ImageByteFormat.rawRgba))!;
  final out = Uint8List(kW * kH);
  for (var i = 0; i < kW * kH; i++) {
    out[i] = data.getUint8(i * 4) > 110 ? 1 : 0;
  }
  return out;
}

/// 1 bit per pixel, MSB first, rows of 16 bytes -> 1024 bytes.
Uint8List packBits(Uint8List a) {
  final out = Uint8List(kW * kH ~/ 8);
  for (var y = 0; y < kH; y++) {
    for (var x = 0; x < kW; x++) {
      if (a[y * kW + x] != 0) out[y * (kW ~/ 8) + (x >> 3)] |= 0x80 >> (x & 7);
    }
  }
  return out;
}

/// Draws a 1-bit picture (used for the editor and slot thumbnails).
class PixelPainter extends CustomPainter {
  final Uint8List px;
  final int rev;
  PixelPainter(this.px, [this.rev = 0]);

  @override
  void paint(Canvas c, Size s) {
    c.drawRect(Offset.zero & s, Paint()..color = Colors.black);
    final p = Paint()
      ..color = const Color(0xFF3DE0FF)
      ..isAntiAlias = false;
    final sx = s.width / kW, sy = s.height / kH;
    for (var y = 0; y < kH; y++) {
      var x = 0;
      while (x < kW) {
        if (px[y * kW + x] == 0) {
          x++;
          continue;
        }
        final x0 = x;
        while (x < kW && px[y * kW + x] != 0) {
          x++;
        }
        c.drawRect(Rect.fromLTRB(x0 * sx, y * sy, x * sx, (y + 1) * sy), p);
      }
    }
  }

  @override
  bool shouldRepaint(PixelPainter o) => !identical(o.px, px) || o.rev != rev;
}
